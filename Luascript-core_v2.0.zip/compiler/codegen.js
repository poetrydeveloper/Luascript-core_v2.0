// compiler/codegen.js
//
// luaScript 2.0 -> Luau Code Generator
//
// The generator consumes the explicit AST produced by parser.js.
// It must never infer parser structures from partially known shapes.
//
// Supported:
// - classes / constructors / methods / fields
// - structs
// - local declarations
// - assignments
// - if / elseif / else
// - for ... in ...
// - return / break
// - calls / member calls
// - table literals
// - index expressions
// - arithmetic / logical expressions
// - super(...)

class CodegenError extends Error {
    constructor(message, node = null) {
        super(message);
        this.name = "CodegenError";
        this.code = "LS004";
        this.node = node;
    }
}

class CodeGenerator {
    constructor() {
        this.lines = [];
        this.indentLevel = 0;
    }

    generate(ast) {
        if (!ast || ast.type !== "Program") {
            throw new CodegenError(
                "Expected Program AST."
            );
        }

        this.lines = [];
        this.indentLevel = 0;

        for (const declaration of ast.declarations) {
            this.emitDeclaration(declaration);
        }

        return this.lines.join("\n");
    }

    emitDeclaration(node) {
        switch (node.type) {
            case "ClassDeclaration":
                this.emitClass(node);
                break;

            case "StructDeclaration":
                this.emitStruct(node);
                break;

            case "DecoratorGroup":
                // Decorators are semantic metadata.
                // They are consumed by the validator/runtime
                // pipeline and do not directly emit Luau.
                break;

            default:
                throw new CodegenError(
                    `Unsupported declaration: ${node.type}`,
                    node
                );
        }
    }

    // ------------------------------------------------------------
    // Classes
    // ------------------------------------------------------------

    emitClass(node) {
        this.write(`local ${node.name} = {}`);
        this.write(`${node.name}.__index = ${node.name}`);
        this.write("");

        for (const member of node.members || []) {
            switch (member.type) {
                case "FieldDeclaration":
                    this.emitField(node, member);
                    break;

                case "ConstructorDeclaration":
                    this.emitConstructor(node, member);
                    break;

                case "MethodDeclaration":
                    this.emitMethod(node, member);
                    break;

                default:
                    throw new CodegenError(
                        `Unsupported class member: ${member.type}`,
                        member
                    );
            }

            this.write("");
        }
    }

    emitField(classNode, node) {
        if (
            node.initializer === null ||
            node.initializer === undefined
        ) {
            return;
        }

        const value = this.emitExpression(
            node.initializer
        );

        this.write(
            `${classNode.name}.${node.name} = ${value}`
        );
    }

    emitConstructor(classNode, node) {
        const parameters = (node.parameters || [])
            .map(parameter => parameter.name)
            .join(", ");

        this.write(
            `function ${classNode.name}.new(${parameters})`
        );

        this.indent();

        this.write(
            `local self = setmetatable({}, ${classNode.name})`
        );

        for (const parameter of node.parameters || []) {
            this.write(
                `self.${parameter.name} = ${parameter.name}`
            );
        }

        this.emitBody(node.body);

        this.write("return self");

        this.dedent();
        this.write("end");
    }

    emitMethod(classNode, node) {
        const parameters = (node.parameters || [])
            .map(parameter => parameter.name)
            .join(", ");

        const args = parameters.length > 0
            ? `self, ${parameters}`
            : "self";

        if (node.visibility === "private") {
            this.write(
                `local function ${node.name}(${args})`
            );
        } else {
            this.write(
                `function ${classNode.name}.${node.name}(${args})`
            );
        }

        this.indent();

        this.emitBody(node.body);

        this.dedent();

        this.write("end");
    }

    // ------------------------------------------------------------
    // Structs
    // ------------------------------------------------------------

    emitStruct(node) {
        this.write(`type ${node.name} = {`);

        this.indent();

        for (const field of node.fields || []) {
            const fieldType = this.emitType(
                field.fieldType
            );

            this.write(
                `${field.name}: ${fieldType},`
            );
        }

        this.dedent();

        this.write("}");
    }

    // ------------------------------------------------------------
    // Statements
    // ------------------------------------------------------------

    emitBody(body) {
        if (!body) {
            return;
        }

        for (const statement of body) {
            this.emitStatement(statement);
        }
    }

    emitStatement(node) {
        if (!node) {
            return;
        }

        switch (node.type) {
            case "ExpressionStatement":
                this.write(
                    this.emitExpression(node.expression)
                );
                break;

            case "VariableDeclaration":
                this.emitVariableDeclaration(node);
                break;

            case "AssignmentStatement":
                this.emitAssignment(node);
                break;

            case "IfStatement":
                this.emitIf(node);
                break;

            case "ForInStatement":
                this.emitForIn(node);
                break;

            case "ReturnStatement":
                this.emitReturn(node);
                break;

            case "BreakStatement":
                this.write("break");
                break;

            default:
                throw new CodegenError(
                    `Unsupported statement: ${node.type}`,
                    node
                );
        }
    }

    emitVariableDeclaration(node) {
        const declarations = node.declarations || [];

        if (declarations.length === 0) {
            throw new CodegenError(
                "VariableDeclaration contains no declarations.",
                node
            );
        }

        const names = declarations
            .map(declaration => declaration.name)
            .join(", ");

        let initializer = "";

        if (
            node.initializer !== null &&
            node.initializer !== undefined
        ) {
            const values = Array.isArray(node.initializer)
                ? node.initializer
                : [node.initializer];

            initializer =
                " = " +
                values
                    .map(value =>
                        this.emitExpression(value)
                    )
                    .join(", ");
        }

        this.write(
            `local ${names}${initializer}`
        );
    }

    emitAssignment(node) {
        this.write(
            `${this.emitExpression(node.target)} = ${this.emitExpression(node.value)}`
        );
    }

    emitReturn(node) {
        if (node.value) {
            this.write(
                `return ${this.emitExpression(node.value)}`
            );
        } else {
            this.write("return");
        }
    }

    emitIf(node) {
        this.write(
            `if ${this.emitExpression(node.condition)} then`
        );

        this.indent();

        this.emitBody(node.consequent);

        this.dedent();

        for (const clause of node.elseIfClauses || []) {
            this.write(
                `elseif ${this.emitExpression(clause.condition)} then`
            );

            this.indent();

            this.emitBody(clause.consequent);

            this.dedent();
        }

        if (node.alternate) {
            this.write("else");

            this.indent();

            this.emitBody(node.alternate);

            this.dedent();
        }

        this.write("end");
    }

    emitForIn(node) {
        const variables = (node.variables || [])
            .map(variable => {
                if (typeof variable === "string") {
                    return variable;
                }

                return variable.name;
            })
            .join(", ");

        if (!variables) {
            throw new CodegenError(
                "ForInStatement contains no iterator variables.",
                node
            );
        }

        this.write(
            `for ${variables} in ${this.emitExpression(node.iterable)} do`
        );

        this.indent();

        this.emitBody(node.body);

        this.dedent();

        this.write("end");
    }

    // ------------------------------------------------------------
    // Expressions
    // ------------------------------------------------------------

    emitExpression(node) {
        if (!node) {
            throw new CodegenError(
                "Cannot generate empty expression."
            );
        }

        switch (node.type) {
            case "Literal":
                return this.emitLiteral(node.value);

            case "Identifier":
                return node.name;

            case "GroupingExpression":
                return `(${this.emitExpression(node.expression)})`;

            case "UnaryExpression":
                return this.emitUnary(node);

            case "BinaryExpression":
                return this.emitBinary(node);

            case "CallExpression":
                return this.emitCall(node);

            case "MemberExpression":
                return this.emitMember(node);

            case "IndexExpression":
                return this.emitIndex(node);

            case "TableExpression":
                return this.emitTable(node);

            case "SuperCallExpression":
                return this.emitSuperCall(node);

            default:
                throw new CodegenError(
                    `Unsupported expression: ${node.type}`,
                    node
                );
        }
    }

    emitUnary(node) {
        const operand =
            this.emitExpression(node.operand);

        if (node.operator === "not") {
            return `not ${operand}`;
        }

        return `${node.operator}${operand}`;
    }

    emitBinary(node) {
        const left =
            this.emitExpression(node.left);

        const right =
            this.emitExpression(node.right);

        return `${left} ${node.operator} ${right}`;
    }

    emitCall(node) {
        const callee =
            this.emitExpression(node.callee);

        const argumentsList = (node.arguments || [])
            .map(argument =>
                this.emitExpression(argument)
            )
            .join(", ");

        return `${callee}(${argumentsList})`;
    }

    emitMember(node) {
        const object =
            this.emitExpression(node.object);

        if (node.method) {
            return `${object}:${node.property}`;
        }

        return `${object}.${node.property}`;
    }

    emitIndex(node) {
        const object =
            this.emitExpression(node.object);

        const index =
            this.emitExpression(node.index);

        return `${object}[${index}]`;
    }

    emitTable(node) {
        const entries = node.entries || [];

        if (entries.length === 0) {
            return "{}";
        }

        const lines = ["{"];

        for (const entry of entries) {
            const value =
                this.emitExpression(entry.value);

            lines.push(
                `${"    ".repeat(this.indentLevel + 1)}${entry.key} = ${value},`
            );
        }

        lines.push(
            `${"    ".repeat(this.indentLevel)}}`
        );

        return lines.join("\n");
    }

    emitSuperCall(node) {
        const argumentsList = (node.arguments || [])
            .map(argument =>
                this.emitExpression(argument)
            )
            .join(", ");

        return `super(${argumentsList})`;
    }

    // ------------------------------------------------------------
    // Literals / Types / Output
    // ------------------------------------------------------------

    emitLiteral(value) {
        if (value === null) {
            return "nil";
        }

        if (typeof value === "string") {
            return JSON.stringify(value);
        }

        if (typeof value === "boolean") {
            return value ? "true" : "false";
        }

        if (typeof value === "number") {
            if (!Number.isFinite(value)) {
                throw new CodegenError(
                    `Cannot emit non-finite number: ${value}`
                );
            }

            return String(value);
        }

        throw new CodegenError(
            `Unsupported literal value: ${typeof value}`
        );
    }

    emitType(node) {
        if (!node) {
            return "any";
        }

        if (node.type === "TypeReference") {
            return this.mapType(node.name);
        }

        return "any";
    }

    mapType(typeName) {
        switch (typeName) {
            case "number":
                return "number";

            case "string":
                return "string";

            case "boolean":
                return "boolean";

            case "void":
                return "()";

            case "any":
                return "any";

            default:
                return typeName;
        }
    }

    write(line) {
        const indentation =
            "    ".repeat(this.indentLevel);

        this.lines.push(
            indentation + line
        );
    }

    indent() {
        this.indentLevel++;
    }

    dedent() {
        if (this.indentLevel > 0) {
            this.indentLevel--;
        }
    }
}

module.exports = {
    CodeGenerator,
    CodegenError
};
